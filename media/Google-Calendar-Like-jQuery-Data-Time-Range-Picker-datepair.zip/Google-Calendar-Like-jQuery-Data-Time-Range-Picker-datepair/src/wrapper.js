(function(window, document) {

	'use strict';

	//= ./Datepair.js

	window.Datepair = Datepair;

}(window, document));
